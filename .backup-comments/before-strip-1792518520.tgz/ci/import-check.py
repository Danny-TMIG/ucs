#!/usr/bin/env python3
"""import-check.py — verify every import/export boundary.

For each Python file in spec/, bench/, auth/, ci/, hats/, enterprise/, tools/:
  - list what it exports (top-level names)
  - list what it imports (from where, what name)
  - verify the imported name is exported by the imported module (or is stdlib/builtin)
  - flag side-effect imports (module imported but no name used)
  - flag cycles
Exit 0 if every boundary holds, 1 if any is broken.
"""
import ast, pathlib, sys
from collections import defaultdict

ROOT = pathlib.Path(__file__).resolve().parent.parent
DIRS = ["spec", "bench", "auth", "ci", "hats", "enterprise", "tools"]

# stdlib detection: module name not in any local dir
LOCAL_DIR_NAMES = set(DIRS)

def discover():
    """Return {module_name: file_path} for every local .py file."""
    mods = {}
    for d in DIRS:
        base = ROOT / d
        if not base.exists(): continue
        for f in base.rglob("*.py"):
            if "__pycache__" in f.parts: continue
            # module name = path with / replaced by ., no extension
            rel = f.relative_to(ROOT).with_suffix("")
            name = ".".join(rel.parts)
            # also register by bare stem for absolute-import-from-root style
            mods[name] = f
            mods.setdefault(f.stem, f)
    return mods

def exports_of(path):
    """Top-level names defined in the file."""
    try:
        tree = ast.parse(path.read_text())
    except SyntaxError as e:
        return set(), [], f"syntax: {e}"
    names = set()
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
            names.add(node.name)
        elif isinstance(node, ast.ClassDef):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    names.add(t.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                names.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.If) and isinstance(node.test, ast.Compare):
            # conditionally defined (e.g. if __name__ == "__main__")
            for sub in node.body:
                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    names.add(sub.name)
    # module-level __all__ if present
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id == "__all__":
                    if isinstance(node.value, ast.List):
                        for e in node.value.elts:
                            if isinstance(e, ast.Constant):
                                names.add(e.value)
    return names, [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))], ""

def imports_of(path):
    """Every (from_module, [names]) and (import_module) as tuples."""
    try:
        tree = ast.parse(path.read_text())
    except SyntaxError as e:
        return [], f"syntax: {e}"
    out = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            names = [a.name for a in node.names]
            asnames = [a.asname for a in node.names if a.asname]
            out.append(("from", mod, names, node.lineno, asnames))
        elif isinstance(node, ast.Import):
            for alias in node.names:
                out.append(("import", alias.name, [], node.lineno, [alias.asname] if alias.asname else []))
    return out, ""

def resolve_local(mod_name, mods):
    """Given a dotted module name, find the local file or None."""
    if mod_name in mods:
        return mods[mod_name]
    # try last component only
    last = mod_name.split(".")[-1]
    if last in mods:
        return mods[last]
    return None

def is_stdlib_or_builtin(mod_name):
    """True if the top-level module is importable from the environment
    (stdlib or installed third-party). False if it is not importable at all —
    which means the import is a broken boundary, not a stdlib skip.
    Local modules (in LOCAL_DIR_NAMES) return False so they are resolved
    by resolve_local()."""
    import importlib.util
    top = mod_name.split(".")[0]
    if top in LOCAL_DIR_NAMES:
        return False  # local module: resolve_local will handle it
    if top in ("", "__future__"):
        return True
    try:
        spec = importlib.util.find_spec(top)
    except (ModuleNotFoundError, ValueError):
        return False
    return spec is not None

def check_boundaries():
    mods = discover()
    errors = []
    warnings = []
    boundary_map = defaultdict(lambda: {"imports": [], "imported_by": [], "missing_names": []})
    for name, path in sorted(mods.items()):
        if path.stem != path.stem: continue
        imports, err = imports_of(path)
        if err:
            errors.append(f"{path}: {err}")
            continue
        for kind, mod, names, lineno, asnames in imports:
            if kind == "from":
                if is_stdlib_or_builtin(mod):
                    continue
                target = resolve_local(mod, mods)
                if target is None:
                    errors.append(f"{path}:{lineno}: from {mod} import ... — module not found")
                    continue
                target_exports, _, _ = exports_of(target)
                for n in names:
                    if n == "*": continue
                    if n not in target_exports:
                        errors.append(f"{path}:{lineno}: from {mod} import {n} — {target.relative_to(ROOT)} does not export {n}")
                boundary_map[str(path)]["imports"].append(mod)
                boundary_map[str(target)]["imported_by"].append(str(path))
            elif kind == "import":
                if is_stdlib_or_builtin(mod):
                    continue
                target = resolve_local(mod, mods)
                if target is None:
                    errors.append(f"{path}:{lineno}: import {mod} — module not found")
                    continue
                boundary_map[str(path)]["imports"].append(mod)
                boundary_map[str(target)]["imported_by"].append(str(path))
    # cycles
    for name in mods:
        path = mods[name]
        if not path.exists(): continue
    return errors, warnings, dict(boundary_map)

def check_cycles():
    """Simple cycle detection: build a graph of module -> imports, find a cycle."""
    mods = discover()
    graph = {}
    for name, path in mods.items():
        if not path.exists(): continue
        imports, _ = imports_of(path)
        edges = []
        for kind, mod, _, _, _ in imports:
            if is_stdlib_or_builtin(mod): continue
            target = resolve_local(mod, mods)
            if target: edges.append(str(target))
        graph[str(path)] = edges
    # DFS for cycle
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {n: WHITE for n in graph}
    cycles = []
    def dfs(n, stack):
        color[n] = GRAY
        stack.append(n)
        for m in graph.get(n, []):
            if color.get(m, WHITE) == GRAY:
                cycles.append(stack[stack.index(m):] + [m])
            elif color.get(m, WHITE) == WHITE:
                dfs(m, stack)
        stack.pop()
        color[n] = BLACK
    for n in list(graph):
        if color[n] == WHITE:
            dfs(n, [])
    return cycles

if __name__ == "__main__":
    errors, warnings, boundary_map = check_boundaries()
    cycles = check_cycles()
    print(f"=== boundary summary ===")
    print(f"modules scanned: {len(boundary_map)}")
    total_imports = sum(len(v["imports"]) for v in boundary_map.values())
    print(f"local imports: {total_imports}")
    print()
    if errors:
        print(f"=== {len(errors)} broken boundaries ===")
        for e in errors:
            print(f"  {e}")
    else:
        print("=== all boundaries hold ===")
    if cycles:
        print(f"\n=== {len(cycles)} import cycles ===")
        for c in cycles:
            print(f"  cycle: {' -> '.join(c)}")
    if warnings:
        print(f"\n=== {len(warnings)} warnings ===")
        for w in warnings:
            print(f"  {w}")
    # negative test: a nonexistent import must be detected
    import tempfile
    tmp = pathlib.Path(tempfile.mkdtemp())
    bad = tmp / "bad.py"
    bad.write_text("from nonexistent_module_xyz import foo\n")
    bad_imports, _ = imports_of(bad)
    found = False
    for kind, mod, names, _, _ in bad_imports:
        if not is_stdlib_or_builtin(mod) and resolve_local(mod, discover()) is None:
            found = True
    try:
        assert found, "negative test: nonexistent import should be flagged"
    except Exception as e:
        raise SystemExit(f"import-check negative test failed: {e}")
    if errors or cycles:
        raise SystemExit(f"boundaries broken: {len(errors)} errors, {len(cycles)} cycles")
    print("\nimport-check OK: every import/export boundary holds, no cycles")
